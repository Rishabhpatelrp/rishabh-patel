package com.rishabh.dynamodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
